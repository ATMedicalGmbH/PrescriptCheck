## [0.2.0] – 2025-05-XX
### Added
- Videosprechstunde integriert
- Export verschlüsselter Prüfberichte

## [0.1.0] – 2025-05-14
### Initial Release
- Rezeptvalidierung, Apothekenportal, Lizenzsystem
